export const routerOptions = {
  basename: import.meta.env.BASE_URL.replace(/\/$/, ''),
  future: { v7_startTransition: true },
};
