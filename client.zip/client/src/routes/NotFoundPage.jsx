export default function NotFoundPage() {
  return <div className="text-muted">ไม่พบหน้าที่ต้องการ</div>;
}
