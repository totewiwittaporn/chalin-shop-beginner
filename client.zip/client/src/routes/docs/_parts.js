// routes/docs/_parts.js
export function Pill({children}){ return <span className="px-2 py-0.5 rounded-full bg-white/10">{children}</span>; }
